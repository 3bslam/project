import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:your_app_name/screens/chat_screen.dart';
import 'package:your_app_name/widgets/default_button.dart';

class SignUpScreen extends StatefulWidget {
  @override
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  late String _email, _password;

  bool _isLoading = false;

  Future<UserCredential?> signInWithGoogle() async {
    // Trigger the authentication flow
    final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();

    if (googleUser == null) return null;

    // Obtain the auth details from the request
    final GoogleSignInAuthentication googleAuth = await googleUser.authentication;

    // Create a new credential
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );

    // Once signed in, return the UserCredential
    return await _auth.signInWithCredential(credential);
  }

  Future<void> _submitForm() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
    });

    _formKey.currentState!.save();

    try {
      final UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: _email,
        password: _password,
      );

      if (userCredential.user != null) {
        // sign up successful
        // navigate to the home screen or perform any other action
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => ChatScreen(),
          ),
        );
      }
    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        print('The password provided is too weak.');
      } else if (e.code == 'email-already-in-use') {
        print('The account already exists for that email.');
      }
    } catch (e) {
      print(e);
    }

    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Sign Up'),
        ),
        body: Padding(
        padding: const EdgeInsets.all(16.0),
    child: Form(
    key: _formKey,
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.center,
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
    TextFormField(
    onChanged: (value) {
    setState(() {
    _email = value.trim();
    });
    },
    decoration: InputDecoration(
    hintText: 'Email',
    prefixIcon: Icon(Icons.email),
    border: OutlineInputBorder(
    borderRadius: BorderRadius.circular(10),
    ),
    ),
    validator: (value) {
    if (value!.isEmpty) {
    return 'Please enter your email address';
    }
    return null;
    },
    ),
    SizedBox(height: 10),
    TextFormField(
    onChanged: (value) {
    setState(() {
    _password = value.trim();
    });
    },
    obscureText: true,
    decoration: InputDecoration(
    hintText: 'Password',
    prefixIcon: Icon(Icons.lock),
    border: OutlineInputBorder(
    borderRadius: BorderRadius.circular(10),
    ),
    ),
    ),
    SizedBox(height: 20),
    defaultButton(
    text: 'Sign Up',
    function: () async
    ),
    ),
    SizedBox(height: 20),
    defaultButton(
    text: 'Sign Up with Google',
    function: () async {
    setState(() {
    _isLoading = true;
    });
    try {
      final UserCredential? userCredential = await signInWithGoogle();

      if (userCredential?.user != null) {
        // sign up successful
        // navigate to the home screen or perform any other action
      }
    } catch (e) {
      print(e);
    }

    setState(() {
      _isLoading = false;
    });
    },
      background: Colors.redAccent,
      textColor: Colors.white,
    ),
      SizedBox(height: 10),
      defaultButton(
        text: 'Sign Up',
        function: _submitForm,
        background: Colors.teal,
        textColor: Colors.white,
      ),
      ],
    ),
    ),
    );
  }

  Widget defaultButton({
    required String text,
    required Function function,
    required Color background,
    required Color textColor,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        onPressed: () => function(),
        child: Text(
          text,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: textColor,
          ),
        ),
        style: ElevatedButton.styleFrom(
          primary: background,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      ),
    );
  }
}